import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-B6xuSHsQ.js";import"./chunk-I66GZJ75-CV7bs45P.js";import"./chunk-NSK5VX7P-C0xy3_nG.js";import"./chunk-4I5QYGJK-VLY9dIGJ.js";import"./chunk-WRU74C26-BPAZLix-.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-CKWtzKiw.js";import"./chunk-2GRJ4B5K-CW9WZxqG.js";import"./chunk-XXDRQBXY-DqAYeljN.js";import"./chunk-KBJHAD2P-7h342ZMb.js";import"./chunk-W5SLKNZC-Dmb1yTaK.js";import"./chunk-QR6OTTB3-CxtcWgli.js";import"./chunk-7Z6QIM7H-DT4-x6nW.js";import"./chunk-J7OUQ5F2-D8ggkNPQ.js";import"./chunk-ZIRB5QZD-O39ZBUk3.js";import{r as t,t as n}from"./chunk-JQJVKLGR-ZFdEq3q8.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};